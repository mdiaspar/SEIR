input_sheet_tst.xlsx, SEIR_3.r and SEIR_util.r are from a post on April 13 on PHAC slack (https://app.slack.com/client/TGEAPQ16K).

seir_3_out.csv is the output of running SEIR_3.r up to the creation of object out and then saving it in a csv file.
